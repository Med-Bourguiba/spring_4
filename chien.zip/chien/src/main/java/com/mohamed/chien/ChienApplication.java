package com.mohamed.chien;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.rest.core.config.RepositoryRestConfiguration;

import com.mohamed.chien.entities.Chien;
import com.mohamed.chien.service.ChienService;

@SpringBootApplication
public class ChienApplication  implements CommandLineRunner  {
	@Autowired
	ChienService chienService;
	@Autowired
	private RepositoryRestConfiguration repositoryRestConfiguration;
	public static void main(String[] args) {
		SpringApplication.run(ChienApplication.class, args);
	}
	@Override
	public void run(String... args) throws Exception {

		
		repositoryRestConfiguration.exposeIdsFor(Chien.class);
	}
}
