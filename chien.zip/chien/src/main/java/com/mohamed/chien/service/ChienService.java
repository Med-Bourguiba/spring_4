package com.mohamed.chien.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.mohamed.chien.entities.Chien;
import com.mohamed.chien.entities.Race;

public interface ChienService {
	Chien saveChien(Chien c);
	Chien updateChien(Chien c);
	void deleteChien(Chien c);
	void deleteChienById(Long id);
	Chien getChien(Long id);
	List<Chien> getAllChiens();
	Page<Chien> getAllChienParPage(int page, int size);
	List<Chien> findByNomChien(String nom);
	List<Chien> findByNomChienContains(String nom);
	List<Chien> findByNomPrixAdoption (String nom, Double prixAdoption);
	List<Chien> findByRace (Race race);
	List<Chien> findByRaceIdRc(Long id);
	List<Chien> findByOrderByNomChienAsc();
	List<Chien> trierChiensNomsprixAdoption ();
	List<Race> getAllRace();
	

}
