package com.mohamed.chien.entities;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;




@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Race {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
private long idRc;
private String nomRc;
private String descriptionRc;

@OneToMany(mappedBy = "race")
@JsonIgnore
private List<Chien> chiens;

@Override
public String toString() {
	return "Race [idRc=" + idRc + ", nomRc=" + nomRc + ", descriptionRc=" + descriptionRc + ", chiens=" + chiens
			+ "]";
}

public long getIdRc() {
	return idRc;
}

public void setIdRc(long idRc) {
	this.idRc = idRc;
}

public String getNomRc() {
	return nomRc;
}

public void setNomRc(String nomRc) {
	this.nomRc = nomRc;
}

public String getDescriptionRc() {
	return descriptionRc;
}

public void setDescriptionRc(String descriptionRc) {
	this.descriptionRc = descriptionRc;
}

public List<Chien> getChiens() {
	return chiens;
}

public void setChats(List<Chien> chiens) {
	this.chiens = chiens;
}





}
