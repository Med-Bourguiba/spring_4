package com.mohamed.chien.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.mohamed.chien.entities.Chien;
import com.mohamed.chien.entities.Race;
import com.mohamed.chien.repos.ChienRepository;
import com.mohamed.chien.repos.RaceRepository;
@Service

public class ChienServiceImpl implements ChienService{
	@Autowired
	ChienRepository chienRepository;
	@Autowired
	RaceRepository raceRepository;
	@Override
	public Chien saveChien(Chien c) {
	return chienRepository.save(c);
	}
	@Override
	public Chien updateChien(Chien c) {
	return chienRepository.save(c);
	}
	@Override
	public void deleteChien(Chien c) {
		chienRepository.delete(c);
	}
	@Override
	public void deleteChienById(Long id) {
		chienRepository.deleteById(id);
	}
	@Override
	public Chien getChien(Long id) {
	return chienRepository.findById(id).get();
	}
	@Override
	public List<Chien> getAllChiens() {
	return chienRepository.findAll();
	}
	@Override
	public Page<Chien> getAllChienParPage(int page, int size) {
	return chienRepository.findAll(PageRequest.of(page, size));
	}
	@Override
	public List<Chien> findByNomChien(String nom) {
		
		return chienRepository.findByNomChien(nom);
	}
	@Override
	public List<Chien> findByNomChienContains(String nom) {
		
		return chienRepository.findByNomChienContains(nom);
	}
	@Override
	public List<Chien> findByNomPrixAdoption(String nom, Double prixAdoption) {
		
		return chienRepository.findByNomPrixAdoption(nom, prixAdoption);
	}
	@Override
	public List<Chien> findByRace(Race race) {
		
		return chienRepository.findByRace(race);
	}
	@Override
	public List<Chien> findByRaceIdRc(Long id) {
	
		return chienRepository.findByRaceIdRc(id);
	}
	@Override
	public List<Chien> findByOrderByNomChienAsc() {
		
		return chienRepository.findByOrderByNomChienAsc();
	}
	@Override
	public List<Chien> trierChiensNomsprixAdoption() {
		
		return chienRepository.trierChiensNomsPrixAdoption();
	}
	@Override
	public List<Race> getAllRace() {
		return raceRepository.findAll();
	}
}
