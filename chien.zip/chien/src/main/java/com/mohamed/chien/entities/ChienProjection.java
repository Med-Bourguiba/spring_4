package com.mohamed.chien.entities;

import org.springframework.data.rest.core.config.Projection;

@Projection(name = "nomChienl", types = { Chien.class })
public interface ChienProjection {
	public String getNomChien();
}
