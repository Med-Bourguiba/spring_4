package com.mohamed.chien.entities;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PastOrPresent;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;
@Entity
public class Chien {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idChien;
	
	@NotBlank
	@Size (min = 4,max = 15)
	private String nomChien;
	
	
	@Min(value = 10)
	 @Max(value = 10000)
	private Double prixAdoption;
	
	
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@PastOrPresent
	private Date datenaissance;
	@ManyToOne
	private Race race;
	
	public Chien() {
	super();
	}
	public Race getRace() {
		return race;
	}
	public void setRace(Race race) {
		this.race = race;
	}
	public Chien(String nomChien, Double prixAdoption, Date datenaissance) {
	this.nomChien = nomChien;
	this.prixAdoption = prixAdoption;
	this.datenaissance = datenaissance;
	}
	public Long getIdChien() {
		return idChien;
	}
	public void setIdChien(Long idChien) {
		this.idChien = idChien;
	}
	public String getNomChien() {
		return nomChien;
	}
	public void setNomChien(String nomChien) {
		this.nomChien = nomChien;
	}
	public Double getPrixAdoption() {
		return prixAdoption;
	}
	public void setPrixAdoption(Double prixAdoption) {
		this.prixAdoption = prixAdoption;
	}
	public Date getDatenaissance() {
		return datenaissance;
	}
	public void setDatenaissance(Date datenaissance) {
		this.datenaissance = datenaissance;
	}
	@Override
	public String toString() {
		return "Chien [idChien=" + idChien + ", nomChien=" + nomChien + ", prixAdoption="
				+ prixAdoption + ", datenaissance=" + datenaissance + "]";
	}
	
}
