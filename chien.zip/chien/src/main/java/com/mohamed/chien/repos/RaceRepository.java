package com.mohamed.chien.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mohamed.chien.entities.Race;

public interface RaceRepository extends JpaRepository<Race, Long> {

}
