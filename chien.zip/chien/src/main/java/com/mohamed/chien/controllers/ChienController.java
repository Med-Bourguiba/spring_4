package com.mohamed.chien.controllers;

import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.mohamed.chien.entities.Chien;
import com.mohamed.chien.entities.Race;
import com.mohamed.chien.service.ChienService;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

@Controller
public class ChienController {
	@Autowired
	ChienService chienService;
	@RequestMapping("/showCreate")
	public String showCreate(ModelMap modelMap)
	{
		List<Race> rcs = chienService.getAllRace();
		Chien chien1 = new Chien();
		Race rc = new Race ();

		if (!rcs.isEmpty()) {
		    rc = rcs.get(0);
		}

		chien1.setRace(rc);
		modelMap.addAttribute("chien", new Chien());
		modelMap.addAttribute("mode", "new");
		modelMap.addAttribute("races", rcs);
		
		for (Race r : rcs) {
			System.out.println(r);
		}
		
		modelMap.addAttribute("page",0);
		return "formChien";
	}
	
	@RequestMapping("/saveChien")
	public String saveChien(@Valid Chien chien,  BindingResult bindingResult, @ModelAttribute("page") int pageFromPrevious,
		    @RequestParam (name="size", defaultValue = "3") int size,
		    RedirectAttributes redirectAttributes,ModelMap modelMap)
	{ int page;
			System.out.println(chien);
		 if (bindingResult.hasErrors()) {
			 List<Race> rcs = chienService.getAllRace();
			 modelMap.addAttribute("race", rcs);
			 modelMap.addAttribute("mode", "edit");
		        return "formChien";
		    }if (chien.getIdChien()==null) //adding
		        page = chienService.getAllChiens().size()/size; 
		    else //updating
		        page = pageFromPrevious;
		    chienService.saveChien(chien);
		    redirectAttributes.addAttribute("page", page);
		    return "redirect:/listeChiens";
	}
	
	@RequestMapping("/listeChiens")
	public String listeChiens(ModelMap modelMap ,@RequestParam (name="page",defaultValue = "0") int page,
			@RequestParam (name="size", defaultValue = "3") int size)

	{
		Page<Chien> chienl = chienService.getAllChienParPage(page, size);
		modelMap.addAttribute("chiens", chienl);
		 modelMap.addAttribute("pages", new int[chienl.getTotalPages()]);
		modelMap.addAttribute("currentPage", page);
		return "listeChiens";
	}
	@RequestMapping("/supprimerChien")
	public String supprimerChien(@RequestParam("id") Long id,
	 ModelMap modelMap ,@RequestParam (name="page",defaultValue = "0") int page,
	 @RequestParam (name="size", defaultValue = "3") int size)
	{ 
		chienService.deleteChienById(id);
		Page<Chien> chienl = chienService.getAllChienParPage(page, 
				size);
				modelMap.addAttribute("chiens", chienl);
				modelMap.addAttribute("pages", new int[chienl.getTotalPages()]);
				modelMap.addAttribute("currentPage", page);
				modelMap.addAttribute("size", size);

	return "listeChiens";
	}
	@RequestMapping("/modifierChien")
	public String editerChien(@RequestParam("id") Long id, @RequestParam("page") int page,ModelMap modelMap)
	{
		Chien c = chienService.getChien(id);
		List<Race> rcs = chienService.getAllRace();
	modelMap.addAttribute("chien", c);
	modelMap.addAttribute("mode", "edit");
	modelMap.addAttribute("page",page);
	modelMap.addAttribute("race", rcs);
	return "formChien";
	}
	@RequestMapping("/updateChien")
	public String updateChien(@ModelAttribute("chien") Chien chien,
	@RequestParam("date") String date,ModelMap modelMap) throws ParseException 
	{
		//conversion de la date 
		 SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
		 Date datenaissance = dateformat.parse(String.valueOf(date));
		 chien.setDatenaissance(datenaissance);
		 
		 chienService.updateChien(chien);
		 List<Chien> chienl = chienService.getAllChiens();
		 modelMap.addAttribute("chiens", chienl);
		return "listeChiens";
		}
}
