package com.mohamed.chien;

import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;

import com.mohamed.chien.entities.Chien;
import com.mohamed.chien.entities.Race;
import com.mohamed.chien.repos.ChienRepository;
import com.mohamed.chien.service.ChienService;

@SpringBootTest
class ChienApplicationTests {

	@Autowired
	private ChienRepository chienRepository;
	@Autowired
	private ChienService  chienService ;
	@Test
	public void testCreateChien() {
		Chien chien1 = new Chien("Max",30.800,new Date());
		chienRepository.save(chien1);
	}
	@Test
	public void testFindChien()
	{
		Chien c = chienRepository.findById(1L).get(); 
	System.out.println(c);
	}
	@Test
	public void testUpdateChien()
	{
		Chien c = chienRepository.findById(1L).get();
	c.setPrixAdoption(1000.0);
	chienRepository.save(c);
	}
	@Test
	public void testDeleteChien()
	{
		chienRepository.deleteById(1L);;
	}
	@Test
	public void testListerTousChiens()
	{
	List<Chien> chiens = chienRepository.findAll();
	for (Chien c : chiens)
	{
	System.out.println(c);
	}
	}
	@Test
	public void testFindBynomChatContains()
	{
	Page<Chien> chien1 = chienService.getAllChienParPage(0,3);
	System.out.println(chien1.getSize());
	System.out.println(chien1.getTotalElements());
	System.out.println(chien1.getTotalPages());
	chien1.getContent().forEach(c -> {System.out.println(c.toString());
	 });
	
	}
	@Test
	public void testfindByNomChien()
	{
	List<Chien> chien1 = chienRepository.findByNomChien("Max");
	for (Chien c : chien1)
	{
	System.out.println(c);
	}
	}
	@Test
	public void testFindByNomChienContains()
	{
	List<Chien> chien1=chienRepository.findByNomChienContains("r");
	for (Chien c : chien1)
	{
	System.out.println(c);
	} }
	@Test
	public void testfindByNomPrixAdoption()
	{
	List<Chien> chien1 = chienRepository.findByNomPrixAdoption("Max", 30.0);
	for (Chien c : chien1)
	{
	System.out.println(c);
	}
	}

	@Test
	public void testfindByRace()
	{
		Race Rc = new Race();
	
	List<Chien> chien1 = chienRepository.findByRace(Rc);
	for (Chien c : chien1)
	{
	System.out.println(c);
	}
	}
	
	@Test
	public void findByRaceIdRc()
	{
	List<Chien> chien1 = chienRepository.findByRaceIdRc(1L);
	for (Chien c : chien1)
	{
	System.out.println(c);
	}
	 }
	@Test
	public void testfindByOrderByNomChienAsc()
	{
	List<Chien> chien1 = chienRepository.findByOrderByNomChienAsc();
	for (Chien c : chien1)
	{
	System.out.println(c);
	}
	}
	@Test
	public void testTrierChiensNomsprixAdoption()
	{
	List<Chien> chien1 = chienRepository.trierChiensNomsPrixAdoption();
	for (Chien c : chien1)
	{
	System.out.println(c);
	}
	}

}
